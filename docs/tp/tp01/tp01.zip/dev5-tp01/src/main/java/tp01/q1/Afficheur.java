package tp01.q1;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Afficheur générique, capable d'afficher un objet à partir de ses méthodes.
 * (en fait d'affichage, on retourne une string, c'est plus simple à tester)
 */
public class Afficheur {
    /**
     * Affiche un objet quelconque par introspection.
     * 
     * @param o
     * @return
     */
    public String afficher(Object o) {
        try {
            Class<? extends Object> clazz = o.getClass();
            ArrayList<String> listeAAfficher = new ArrayList<>();
            for (Method m : clazz.getMethods()) {
                if (m.getName().startsWith("get") && m.getParameterCount() == 0 
                && ! m.getName().equals("getClass")) {
                    String nomPropriete = IntrospectionHelper.extraireNomDePropriete("get", m.getName());
                    listeAAfficher.add(nomPropriete + " : " + m.invoke(o));
                }
            }
            Collections.sort(listeAAfficher);
            return String.join(" ; ", listeAAfficher);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

}
