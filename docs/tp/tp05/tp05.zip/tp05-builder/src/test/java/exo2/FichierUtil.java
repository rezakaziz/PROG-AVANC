package exo2;

public class FichierUtil {
    public static final String dataEtudiants=
            "1:Turing:Alan:10:12:13:7:15\n" 
        + "2:Lovelace:AdA:18:15:19\n" 
        + "3:Wirth:Niklaus:12:10:13:13\n";        
}
