package fip1;

/**
 * Une collection de méthodes statiques liées à la classe "MaListe"
 */
public class MaListeHelper {
    
}
