package fip1;

import java.util.Arrays;

public class MaListe {
    
}
