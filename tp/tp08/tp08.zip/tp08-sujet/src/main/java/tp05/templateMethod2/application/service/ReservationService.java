package tp05.templateMethod2.application.service;

import java.util.List;

import tp05.templateMethod2.application.modele.Reservation;
import tp05.templateMethod2.application.modele.Siege;

public interface ReservationService {
    
    /**
     * Ajoute un nouveau siège (devrait plutôt être dans un backend, ceci dit)
     * @param numeroVoiture
     * @param numeroPlace
     */
    void creerSiege(int numeroVoiture, int numeroPlace);

    /**
     * Liste les sièges disponibles (non réservés).
     * Vous pouvez avoir envie de modifier l'une des DAO pour cela,
     * ou calculer le résultat en Java.
     * @return
     */
    List<Siege> siegesDisponibles();

    /**
     * Passer une réservation pour un client.
     * S'il y a un siège disponible, il lui est attribué.
     * Sinon, on utilise l'id 0 comme id de siège.
     * @param nomClient
     * @return
     */
    Reservation reserver(String nomClient);

    List<Reservation> reservations();
}
