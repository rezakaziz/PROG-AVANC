package tp05.templateMethod2.application;

import java.sql.SQLException;
import tp05.templateMethod2.application.dao.DbDefinition;
import tp05.templateMethod2.application.dao.IdDAO;
import tp05.templateMethod2.application.dao.ReservationDAO;
import tp05.templateMethod2.application.dao.SiegeDAO;
import tp05.templateMethod2.application.modele.Reservation;
import tp05.templateMethod2.application.modele.Siege;

public class Q1 {
    
    public void run() throws SQLException {
         // Pour l'instant, du code sans grande structure...
         DbDefinition db = new DbDefinition();
         db.initialiserDB();
         // On crée un siège :
         IdDAO idDao = new IdDAO();
         SiegeDAO siegeDAO = new SiegeDAO();
         Siege siege = new Siege(idDao.getNextId(), 6, 10);
         siegeDAO.save(siege);
         ReservationDAO reservationDAO = new ReservationDAO();
         reservationDAO.save(new Reservation(idDao.getNextId(), "Lovelace", siege.getId()));
         // On vérifie qu'on a bien tout sauvé et récupéré :        
         System.out.println(siegeDAO.findAll());
         System.out.println(reservationDAO.findAll());
    }
}
