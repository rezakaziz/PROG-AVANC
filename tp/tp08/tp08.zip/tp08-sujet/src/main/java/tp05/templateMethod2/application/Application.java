package tp05.templateMethod2.application;

import tp05.templateMethod2.application.modele.Reservation;
import tp05.templateMethod2.application.service.ReservationService;

/**
 * L'application elle-même. Pour l'instant vide, mais sera remplie et tournera...
 */
public class Application {

    /**
     * Ce service sera créé et injecté...
     */
    private ReservationService reservationService;

    /**
     * Simulation d'une session...
     */
    public void run() {
        // a) créer quelques sièges...
        for (int i=1; i <= 5; i++) {
            reservationService.creerSiege(1, i);
        }
        // b) faire quelques réservations...
        for (int j=0; j < 3; j++) {
            reservationService.reserver("client"+j);
        }
        // c) voir les places disponibles..
        System.out.println(reservationService.siegesDisponibles());
        // d) réserver encore...
        reservationService.reserver("a");
        reservationService.reserver("b");
        // e) normalement, plus de place :
        System.out.println(reservationService.siegesDisponibles());
        // f) on réserve, et on devrait ne pas avoir de siège (mais la réservation est enregistrée quand même).
        Reservation res = reservationService.reserver("client malchanceux");
        System.out.println("Le client "+ res.getClient() + "a-t-il un siège "+ res.aSiegeAttribue());
    }

    /**
     * Le bon endroit pour fermer les ressources qui doivent l'être (comme la connexion) !
     * Cette méthode devra être appelée à la fin de l'exécution du logiciel... On pourrait évidemment 
     * utiliser une fois de plus le pattern template method pour en être sûr !!
     */
    public void terminerApplication() {

    }
    
}
