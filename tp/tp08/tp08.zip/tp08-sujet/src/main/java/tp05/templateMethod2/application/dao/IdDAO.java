package tp05.templateMethod2.application.dao;


import tp05.templateMethod2.utilitaires.template.SQLSimpleHelper;

/**
 * Un générateur d'ids.
 */
public class IdDAO extends AbstractDAO {
    
    public long getNextId() {
        String sql = "SELECT NEXT VALUE FOR SEQUENCE_ID";
        return SQLSimpleHelper.sqlIntQuery(getConnection(), sql);
    }
}
