package tp05.templateMethod2.application;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
       Q1 q1 = new Q1();
       q1.run();
    }
}
